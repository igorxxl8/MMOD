import numpy as np


def generate_white_noise(n):
    m = 0
    sigma = 1

    return np.random.normal(m, sigma, n)
