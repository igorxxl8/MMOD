import numpy as np
from math import sqrt, exp, pi

from lab_3.white_noise_modeling import generate_white_noise


def generate_random_process(time_size, delta_tau, n, sigma_x, sigma_y, alpha):
    time_line = get_time_line(time_size, delta_tau)
    x = generate_white_noise(len(time_line))
    y = generate_y(x, delta_tau, n, sigma_x, sigma_y, alpha)

    return y


def generate_y(x, delta_tau, n, sigma_x, sigma_y, alpha):
    y = []

    for j in range(len(x)):
        y_j = 0

        for i in range(n):
            dt = i * delta_tau
            y_j += h(dt, sigma_x, sigma_y, alpha) * x[j - i]

        y.append(delta_tau * y_j)

    return y


def h(tau, sigma_x, sigma_y, alpha):
    return sigma_y / sigma_x * sqrt((2 * alpha ** 5 / (3 * pi))) * exp(-alpha * tau) * tau ** 2


def get_time_line(time_size, delta_tau):
    return np.arange(1, time_size, delta_tau)


# def generate_random_process_recursion(time_size, delta_tau, alpha):
#     gamma = alpha * delta_tau
#     p = exp(-gamma)
#
#     alpha_0 = p ** 4 * (gamma ** 2 / 3 + gamma + 1) - p ** 2 * (gamma ** 2 / 3 - gamma + 1)
#     alpha_1 = p ** 5 * (gamma ** 2 / 3 - gamma - 2) - 6 * gamma * p ** 3 - p * (gamma ** 2 / 3 + gamma - 2)
#     alpha_2 = p ** 6 - p ** 4 * (2 * gamma ** 2 - 6 * gamma - 3) + p ** 2 * (2 * gamma ** 2 + 6 * gamma - 3) - 1
#
#     y_1 = (-alpha_1 + sqrt(alpha_1 ** 2 - 4 * alpha_0 * alpha_2 + 8 * alpha_0 ** 2)) / (2 * alpha_0)
#     y_2 = (-alpha_1 - sqrt(alpha_1 ** 2 - 4 * alpha_0 * alpha_2 + 8 * alpha_0 ** 2)) / (2 * alpha_0)
#
#     a_0 = sqrt(-alpha_0 * (y_1 + sqrt(y_1 ** 2 - 4)) * (y_2 + sqrt(y_2 ** 2 - 4)) / 2)
#     a_2 = sqrt(-alpha_0 * 2 / ((y_1 + sqrt(y_1 ** 2 - 4)) * (y_2 + sqrt(y_2 ** 2 - 4))))
#     a_1 = -a_2 * ((y_1 + sqrt(y_1 ** 2 - 4)) + (y_2 + sqrt(y_2 ** 2 - 4))) ** 2
#
#     b_1 = -3 * p
#     b_2 = 3 * p ** 2
#     b_3 = -p ** 3
#
#     time_line = np.arange(1, time_size, delta_tau)
#     x = generate_white_noise(len(time_line))
#     y = [0, 0, 0]
#     print(y_1)
#
#     for i in range(3, len(time_line)):
#         y_0 = a_0 * x[i] + a_1 * x[i - 1] + a_1 * x[i - 2] + b_1 * y[i - 1] + b_2 * y[i - 2] + b_3 * y[i - 3]
#         print(y_0)
#         y.append(y_0)
#
#     return x, y, time_line
#
#
# def test(time_size, delta_tau, alpha):
#     gamma = alpha * delta_tau
#     p = exp(-gamma)
#     a0 = sqrt(1 - p ** 2)
#     b1 = p
#     y = [0]
#     time_line = np.arange(1, time_size, delta_tau)
#     x = generate_white_noise(len(time_line))
#     for i in range(1, len(time_line)):
#         y.append(a0 * x[i] + b1 * y[i - 1])
#     return x, y, time_line
