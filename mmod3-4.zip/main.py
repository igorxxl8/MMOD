from lab_1 import distribution_research, rbv_generator, crv_modeling, drv_modeling
from lab_1.disrtibution import *
from lab_2 import crvs_modeling, drvs_modeling
from lab_2 import distribution_research_system
from lab_3 import rp_modeling
from lab_3 import rp_research
from lab_4 import queuing_system_modeling_live, queuing_system_modeling


def lab_1():
    Q = 0.99
    N = 10000

    def a():
        M = 1 / 2
        D = 1 / 12
        S = 3

        random_values = [rbv_generator.get_next() for _ in range(N)]
        distribution_research.do_research_continues(random_values, N, M, D, Q, UNIFORM, s=S)

    def b_first_method():
        M = 0
        D = 1
        SIGMA = sqrt(D)

        random_values = [crv_modeling.get_next(M, SIGMA) for _ in range(N)]
        distribution_research.do_research_continues(random_values, N, M, D, Q, NORMAL)

    def b_second_method():
        M = 0
        D = 1
        SIGMA = sqrt(D)

        normal_random_values = []

        for _ in range(N // 2):
            value_1, value_2 = crv_modeling.get_next_s(M, SIGMA)
            normal_random_values.append(value_1)
            normal_random_values.append(value_2)

        distribution_research.do_research_continues(normal_random_values, N, M, D, Q, NORMAL)

    def b_third_algorithm():
        M = 0
        D = 1
        SIGMA = sqrt(D)

        random_values = [crv_modeling.get_next_n(M, SIGMA) for _ in range(N)]
        distribution_research.do_research_continues(random_values, N, M, D, Q, NORMAL)

    def c():
        P = 0.5
        L = 5
        K = 20

        distribution = drv_modeling.DiscreteDistribution(GEOMETRIC, n=K, p=P)
        # distribution = drv_modeling.DiscreteDistribution(POISSON, n=K, l=L)

        M = distribution.m
        D = distribution.d

        random_values = [drv_modeling.get_next(distribution) for _ in range(N)]
        distribution_research.do_research_discrete(random_values, N, K, M, D, Q, distribution)

    a()
    # b_first_method()
    # b_second_method()
    b_third_algorithm()
    c()


def lab_2():
    N = 100000

    def a():
        random_values_system = [crvs_modeling.get_next_x_y() for _ in range(N)]
        distribution_research_system.do_research_continues(random_values_system)

    def b():
        random_values_system = drvs_modeling.get_empirical_matrix(N)
        distribution_research_system.do_research_discrete(random_values_system, N)

    a()
    b()


def lab_3():
    sigma_x = 1
    sigma_y = 2
    alpha = 0.5
    delta_tau_max = 8.03 / alpha
    n = 10
    time_size = 10000
    delta_tau = delta_tau_max / n
    k = 10

    random_process = []
    for _ in range(k):
        y = rp_modeling.generate_random_process(time_size, delta_tau, n, sigma_x, sigma_y, alpha)
        random_process.append(y)

    time_line = rp_modeling.get_time_line(time_size, delta_tau)
    rp_research.do_research(random_process, time_line)


def lab_4():
    n = 2
    m = 2
    request_intensity = 1.5  # lambda
    service_intensity = 1  # mu
    time_interval_for_info = 2
    p = 0.5

    run_life_time = 1000

    queuing_system_modeling.start(
        n,
        m,
        request_intensity,
        service_intensity,
        p,
        run_life_time
    )

    queuing_system_modeling_live.start(
        n,
        m,
        request_intensity,
        service_intensity,
        time_interval_for_info,
        p
    )


if __name__ == '__main__':
    # lab_1()
    # lab_2()
    lab_3()
    # lab_4()
