from statistics import mean

import numpy as np
from math import log, factorial
from threading import Timer
from time import time
from datetime import datetime


number_of_channels = 0
queue_size = 0
request_intensity = 0
service_intensity = 0
time_interval_info = 0
probability_to_serve_the_request = 0

done_requests = []
done_requests_ids = []
rejected_requests = []
cancelled_requests = []

service_channels = []
queue = []
queue_ids = []

request_number = 0
time_division = 100


def start(n, m, lambda_, mu, time_interval_for_info, p):
    init(n, m, lambda_, mu, time_interval_for_info, p)

    get_queuing_system_info()
    get_queuing_system_statistic()

    while request_number < 100:
        process_queue()

    show_statistic()


def init(n, m, lambda_, mu, time_interval_for_info, p):
    global number_of_channels, queue_size, request_intensity, \
        service_intensity, service_channels, time_interval_info, probability_to_serve_the_request

    number_of_channels = n
    queue_size = m
    request_intensity = lambda_
    service_intensity = mu
    service_channels = [None for _ in range(n)]
    time_interval_info = time_interval_for_info
    probability_to_serve_the_request = p

    send_new_request()


def send_new_request():
    global request_number

    request_number += 1

    time_interval = request_time_generator()

    timer = Timer(
        time_interval,
        dispatcher,
        args=(True, request_number, None, None, None, None)
    )
    timer.start()


def dispatcher(*args):
    is_new_request, request_id, _, _, _, _ = args

    if is_new_request:
        try_to_process_request(request_id)
        send_new_request()
        return

    _, request_id, time_in_queue, start_time, time_in_serve, channel_index = args

    is_accept = accept_request()
    if is_accept:
        done_request(request_id, time_in_queue, start_time, time_in_serve, channel_index)
    else:
        cancel_request(request_id, channel_index)
        try_to_process_request(request_id)


def try_to_process_request(request_id):
    if len(queue) < queue_size:
        queue_the_request(request_id)
    else:
        reject_request(request_id)


def queue_the_request(request_id):
    queue.append((request_id, time()))
    queue_ids.append(request_id)


def reject_request(request_id):
    rejected_requests.append(request_id)


def done_request(request_id, time_in_queue, start_time, time_in_serve, channel_index):
    free_channel(channel_index)

    time_in_queuing_system = time() - start_time

    done_requests.append((request_id, time_in_queue, time_in_queuing_system, time_in_serve))
    done_requests_ids.append(request_id)


def cancel_request(request_id, channel_index):
    cancelled_requests.append(request_id)
    free_channel(channel_index)


def process_queue():
    free_channel_index = find_free_channel()

    if len(queue) == 0 or free_channel_index == -1:
        return

    request_id, start_time = queue.pop(0)
    queue_ids.pop(0)
    time_in_queue = time() - start_time
    serve_request(request_id, time_in_queue, start_time, free_channel_index)


def find_free_channel():
    if service_channels.__contains__(None):
        return service_channels.index(None)

    return -1


def serve_request(request_id, time_in_queue, start_time, free_channel_index):
    service_channels[free_channel_index] = request_id

    time_interval = serve_time_generator()

    timer = Timer(
        time_interval,
        dispatcher,
        args=(False, request_id, time_in_queue, start_time, time_interval, free_channel_index)
    )
    timer.start()


def free_channel(channel_index):
    service_channels[channel_index] = None


def request_time_generator():
    return exponential_value_generator(request_intensity)


def serve_time_generator():
    return exponential_value_generator(service_intensity)


def exponential_value_generator(intensity):
    return - 1 / intensity * log(1 - np.random.uniform())


def accept_request():
    return np.random.choice([True, False], p=[probability_to_serve_the_request, 1 - probability_to_serve_the_request])


def get_info():
    print(f'\nТекущее время: {datetime.now().time()}')
    if len(done_requests_ids) < 15:
        print(f'Обслуженные заявки: {done_requests_ids}')
    else:
        print(f'Кол-во обслуженных заявок: {len(done_requests_ids)}')

    if len(rejected_requests) < 15:
        print(f'Необслуженные заявки: {rejected_requests}')
    else:
        print(f'Кол-во необслуженных заявок: {len(rejected_requests)}')

    if len(cancelled_requests) < 15:
        print(f'Отмененные заявки: {cancelled_requests}')
    else:
        print(f'Кол-во отмененных заявок: {len(cancelled_requests)}')

    print(f'Состояние очереди: {queue_ids}')
    print(f'Состояние каналов: {service_channels}')

    get_queuing_system_info()


def get_queuing_system_info():
    timer = Timer(
        time_interval_info,
        get_info
    )
    timer.start()


def get_final_probabilities():
    final_probabilities = []
    n = number_of_channels
    m = queue_size
    lambda_ = request_intensity
    mu = service_intensity
    p = probability_to_serve_the_request

    p0 = (sum([lambda_ ** i / (factorial(i) * (mu * p) ** i) for i in range(n + 1)]) +
          sum([lambda_ ** i / (factorial(n) * n ** (i - n) * (mu * p) ** i) for i in range(n + 1, n + m)]) +
          lambda_ ** (n + m) / (factorial(n) * n ** m * mu ** (n + m) * p ** (n + m - 1))) ** -1

    final_probabilities.append(p0)

    for i in range(1, n + 1):
        p_ = lambda_ ** i / (factorial(i) * (mu * p) ** i) * p0
        final_probabilities.append(p_)

    for i in range(n + 1, n + m + 1):
        p_ = lambda_ ** i / (factorial(n) * n ** (i - n) * (mu * p) ** i) * p0
        final_probabilities.append(p_)

    return final_probabilities


def get_average_number_of_request_in_queue(final_probabilities):
    n = number_of_channels
    m = queue_size

    return sum([i * final_probabilities[n + i] for i in range(1, m + 1)])


def get_queuing_system_statistic():
    timer = Timer(
        1 / time_division,
        get_statistic
    )
    timer.start()


channels_and_queue_state = []
channels_state = []
queue_state = []


def get_statistic():
    n = number_of_channels
    channels_and_queue_state.append(n - service_channels.count(None) + len(queue))
    channels_state.append(n - service_channels.count(None))
    queue_state.append(len(queue))

    get_queuing_system_statistic()


def get_empirical_final_probabilities():
    empirical_final_probabilities = []

    n = number_of_channels
    m = queue_size

    n_ = len(channels_and_queue_state)
    for i in range(n + m + 1):
        p = channels_and_queue_state.count(i) / n_
        empirical_final_probabilities.append(p)

    return empirical_final_probabilities


def get_empirical_average_service_request_time():
    average_service_request_time = []

    for i in range(len(done_requests)):
        average_service_request_time.append(done_requests[i][2])

    return mean(average_service_request_time)


def get_empirical_average_queue_time():
    average_queue_time = []

    for i in range(len(done_requests)):
        average_queue_time.append(done_requests[i][1])

    return mean(average_queue_time)


def get_empirical_average_request_time_in_system():
    average_request_time_in_system = []

    for i in range(len(done_requests)):
        average_request_time_in_system.append(done_requests[i][3])

    return mean(average_request_time_in_system)


def get_relative_bandwidth():
    return len(done_requests) / (len(done_requests) + len(rejected_requests))


def get_average_channel_usage(final_probabilities):
    n = number_of_channels
    m = queue_size

    return (sum([i * final_probabilities[i] for i in range(n + 1)]) +
            sum([n * final_probabilities[n + i] for i in range(1, m + 1)]))


def show_statistic():
    final_probabilities = get_final_probabilities()
    probability_of_idle_channels = final_probabilities[0]
    denial_of_service_probability = final_probabilities[-1]
    relative_bandwidth = 1 - denial_of_service_probability
    absolute_bandwidth = request_intensity * relative_bandwidth
    average_channel_usage = get_average_channel_usage(final_probabilities)
    average_number_of_request_in_queue = get_average_number_of_request_in_queue(final_probabilities)
    average_number_of_request_in_system = average_channel_usage + average_number_of_request_in_queue
    average_service_request_time = average_channel_usage / request_intensity
    average_queue_time = average_number_of_request_in_queue / request_intensity
    average_request_time_in_system = average_service_request_time + average_queue_time

    final_probabilities_empirical = get_empirical_final_probabilities()
    probability_of_idle_channels_empirical = final_probabilities_empirical[0]
    denial_of_service_probability_empirical = final_probabilities_empirical[-1]
    relative_bandwidth_empirical = 1 - denial_of_service_probability_empirical
    absolute_bandwidth_empirical = request_intensity * relative_bandwidth_empirical
    average_channel_usage_empirical = mean(channels_state)
    average_number_of_request_in_queue_empirical = mean(queue_state)
    average_number_of_request_in_system_empirical = mean(channels_and_queue_state)
    average_service_request_time_empirical = get_empirical_average_service_request_time()
    average_queue_time_empirical = get_empirical_average_queue_time()
    average_request_time_in_system_empirical = get_empirical_average_request_time_in_system()

    print('Теоритические и эмпирические характеристики:')
    print(f'Финальные вероятности: {final_probabilities} -\n\t\t\t\t\t\t{final_probabilities_empirical}')
    print(f'Вероятность простоя каналов: {probability_of_idle_channels} - {probability_of_idle_channels_empirical}')
    print(f'Вероятность отказа обсуживания: {denial_of_service_probability} - '
          f'{denial_of_service_probability_empirical}')
    print(f'Относительная пропускная способность: {relative_bandwidth} - {relative_bandwidth_empirical}')
    print(f'Абсолютная пропускная способность: {absolute_bandwidth} - {absolute_bandwidth_empirical}')
    print(f'Среднее число занятых каналов: {average_channel_usage} - {average_channel_usage_empirical}')
    print(f'Среднее число заявок в очереди: {average_number_of_request_in_queue} - '
          f'{average_number_of_request_in_queue_empirical}')
    print(f'Среднее число заявок в системе: {average_number_of_request_in_system} - '
          f'{average_number_of_request_in_system_empirical}')
    print(f'Среднее время заявки под обслуживанием: {average_service_request_time} - '
          f'{average_service_request_time_empirical}')
    print(f'Среднее время заявки в очереди: {average_queue_time} - {average_queue_time_empirical}')
    print(f'Среднее время заявки в системе: {average_request_time_in_system} - '
          f'{average_request_time_in_system_empirical}')